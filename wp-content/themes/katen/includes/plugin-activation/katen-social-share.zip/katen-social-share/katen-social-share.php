<?php 
/*
Plugin Name: Katen Theme Post Social Share
Plugin URI: https://themeforest.net/user/themeger
Description: Katen Social Share
Author: ThemeGer
Author URI: https://themeger.shop
Version: 1.0
Text Domain: katen
*/
include_once( 'loader.php' );